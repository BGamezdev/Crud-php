<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "prueba";

$con = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

$id=$_GET['id'];
$sql = mysqli_query($con,"SELECT * FROM test1 where id ='$id' ");
while($consulta = mysqli_fetch_array($sql))
?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Actualizar</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/style.css" rel="stylesheet">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    </head>
    <body>
    <div class="container mt-5" >
<form method = "POST" action="registro.php">
                <input type ="text" name ="serial" value="id" size ="1"disabled=»disabled» />
<input type ="text" name ="nombres" value="nombre"/>
<input type ="text" name ="descriptions" value="description"/>
<input type ="submit" name ="btn1"class="btn btn-primary" value = "Guardar"/>
</form>
</body>
</html>