<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "prueba";

$con = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

$SERIAL = $_POST['serial'];
$MODELO = $_POST['nombres'];
$MARCA =  $_POST['descriptions'];

    $sql="UPDATE  test1 set nombre = '$MODELO',description = '$MARCA' WHERE id ='$SERIAL'";
    $query = mysqli_query($con,$sql);
    if($query){
        header("Location:ingreso.php");
    }

?>