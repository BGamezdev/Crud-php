<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "prueba";

$con = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

if ($con==true)
{
//echo ("conexion establecida"   );
}
    if(isset($_POST['btn1']))
    {

      $SERIAL = $_POST['serial'];
      $MODELO = $_POST['nombres'];
      $MARCA =  $_POST['descriptions'];
      
     $nr = mysqli_query($con,   "INSERT INTO test1 (id,nombre,description) values ('$SERIAL','$MODELO','$MARCA')");

      if($nr == 1){
    header("Location:ingreso.php");}


	  
	  
    }

  ?>

