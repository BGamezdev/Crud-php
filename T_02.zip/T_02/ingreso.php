<?php
include("conexion.php");


$sql = mysqli_query($con,"SELECT * FROM test1 ");
while($consulta = mysqli_fetch_array($sql))


?>

<!DOCTYPE html>
<html lang="en">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <head>

        <title>pag usuario</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/style.css" rel="stylesheet">
    </head>
    <body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-3">
                <h1>INGRESE DATOS</h2>
                <form method = "POST" action="registro.php">
                <input type ="text" name ="serial" value="id" disabled=»disabled»/>
<input type ="text" name ="nombres" value="nombre"/>
<input type ="text" name ="descriptions" value="description"/>
<input type ="submit" name ="btn1"class="btn btn-primary" value = "Guardar"/>
</form>


</div>

<div class="col-md-8">
<table class="table">
<thead class="table-primary table-striped">
    <tr>
<th>id</th>
<th>nombre</th>
<th>Description</th>
<th></th>
<th></th>
</tr>
</thead>
<tbody>


<?php

$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "prueba";

$con = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
$resultados = mysqli_query($con,"SELECT * FROM test1 ");
          while($consulta = mysqli_fetch_array($resultados))
			{
?>
<tr>
<th><?php echo $consulta['id']?></th>
<th><?php echo $consulta['nombre'];?></th>
<th><?php echo $consulta['description'];?></th>
<th><a href="actualizar.php?id=<?php echo $consulta['id']; ?>" class="btn btn-success ">Editar</a></th>
<th><a href="delete.php?id=<?php echo $consulta['id']; ?>" class="btn btn-danger" onclick="miFunc()">Borrar</a></th>
<script>
  function miFunc() {
if (confirm("esta seguro de eliminar")){
return true;
} else {
    event.preventdefault();
}
  }

</script>

</tr>
<?php }
?>
</tbody>
</table>
    </div>
    </div>
    </div>
    </body>
</html>



<?php

    $dbhost = "localhost";
    $dbuser = "root";
    $dbpass = "";
    $dbname = "prueba";
$con = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

if ($con==true)
{
//echo ("conexion establecida" );
}
mysqli_select_db($con,$dbname)




?>