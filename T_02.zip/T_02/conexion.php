<?php

    $dbhost = "localhost";
    $dbuser = "root";
    $dbpass = "";
    $dbname = "prueba";

$con = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

mysqli_select_db($con,$dbname);



?>