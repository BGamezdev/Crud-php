<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "prueba";

$con = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

$id=$_GET['id'];

    $sql="DELETE FROM test1 WHERE id=$id";
    $query = mysqli_query($con,$sql);
    if($query){
        header("Location:ingreso.php");
    }

?>
